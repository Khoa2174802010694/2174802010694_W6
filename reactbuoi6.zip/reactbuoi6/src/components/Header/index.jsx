import React from 'react';
import { Link } from 'react-router-dom';

export default function Header({cartItems}) {
  console.log('cartItems: ', cartItems);
  return (
    <header className='flex justify-between items-center p-4 bg-gray-800 text-white'>
        <h1 className='text-xl font-bold'><Link to='/'>Store</Link></h1>
        <Link to='/cart' className='text-blue-400 hover:underline'>
            Go to Cart{cartItems.length}
        </Link>
    </header>
  );
}
