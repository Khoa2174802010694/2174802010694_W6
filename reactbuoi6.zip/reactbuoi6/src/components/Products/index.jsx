import React from 'react';
import { Link } from 'react-router-dom';

export default function Products({handleAddtoCart}) {
  const products = [
    {
      id: 1, 
      productname: "Watch 1", 
      productimg: "https://picsum.photos/200", 
      price: 20000,
      des: "Đồng hồ thể thao: Chiếc đồng hồ này có mặt số tròn với viền nhựa màu đen, dây đeo silicon mềm mại và bền bỉ. Mặt số được thiết kế nổi bật với các số Ả Rập lớn và các chức năng như đồng hồ bấm giờ và hiển thị ngày. Đặc biệt, nó có khả năng chống nước đến 50 mét, rất phù hợp cho những ai yêu thích các hoạt động ngoài trời."
    },
    {
      id: 2, 
      productname: "Watch 2", 
      productimg: "https://picsum.photos/200", 
      price: 30000,
      des: "Đồng hồ cổ điển: Mặt đồng hồ màu trắng kem với vỏ kim loại mạ vàng bóng loáng. Các chỉ số được thiết kế tinh tế bằng số La Mã, tạo cảm giác thanh lịch và sang trọng. Dây da nâu mềm mại ôm sát cổ tay, mang lại sự thoải mái cho người đeo. Chiếc đồng hồ này rất phù hợp với những dịp trang trọng hoặc đi làm."
    },
    {
      id: 3, 
      productname: "Watch 3", 
      productimg: "https://picsum.photos/200", 
      price: 40000,
      des: "Đồng hồ thông minh: Thiết kế hiện đại với màn hình cảm ứng lớn và viền nhôm nhẹ. Nó có nhiều chức năng thông minh như theo dõi nhịp tim, thông báo tin nhắn, và có thể kết nối với điện thoại để kiểm tra thông báo. Dây đeo có thể thay đổi màu sắc và phong cách, giúp người dùng dễ dàng tùy chỉnh theo sở thích cá nhân."
    },
    {
      id: 4, 
      productname: "Watch 4", 
      productimg: "https://picsum.photos/200", 
      price: 50000,
      des: "Đồng hồ vintage: Mặt số bằng gỗ tự nhiên với vân gỗ độc đáo, tạo nên vẻ đẹp tự nhiên và ấm áp. Vỏ đồng hồ bằng đồng cổ điển, mang lại cảm giác vintage mạnh mẽ. Dây đeo được làm từ vải canvas chắc chắn với màu sắc trung tính, rất dễ phối đồ và phù hợp cho những ai yêu thích phong cách hoài cổ."
    },
  ];

  return (
    <section className='container mx-auto p-6'>
      <h2 className='text-2xl font-bold text-center'>Watch List</h2>
      <div className='grid grid-cols-4 gap-4'>
        {
        products.map((product) => {
          return(
          <div key={product.id} className='bg-white shadow-lg p-4 rounded-lg'>
            <img src={product.productimg} alt={product.productname} className='w-80 h-80 object-cover rounded-t-lg' />
            <p className='text-lg font-semibold mt-5'>{product.productname}</p>
            <p>Price: ${product.price}</p>           
            <Link to={`/detail/${product.id}`} state={{product}} className='w-full py-1 px-3 bg-green-400 text-white'>
            Information</Link>
            <button onClick={()=>{ handleAddtoCart(product) }} className='w-full py-1 px-3 bg-blue-400 mt-1 text-white'>Add to Cart</button>
          </div>
          )
        }
      )}
      </div>
    </section>
  )
}