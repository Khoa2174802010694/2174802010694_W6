import React from 'react';
import { useLocation } from 'react-router-dom';

export default function ProductDetail({handleAddtoCart}) {
  const location = useLocation();
  const { product } = location.state || {};
  console.log('product: ', product);

  return (
    <section className='p-6 max-w-3x1 mx-auto border border-gray-200 rounded-lg shadow-lg bg-white mt-10'>
      <h2 className='max-w-md mx-auto text-3x1 font-bold text-gray-500'>{ product?.productname }</h2>
      <div className='max-w-md mx-auto flex gap-6'>     
        <img src={ product.productimg} alt={ product.productname } />
        <div className='w-80 h-80 object-cover shadow-md py-5'>
          <p> Price: { product.price } $</p>
          <p className='text-xs'> <b>Infromation:</b> <br></br>{ product.des }</p>
          <div className='text-end mt-20'>
            <button onClick={ () => { handleAddtoCart(product) }} className='bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover: bg-blue-800 transition-all duration-500'>Add to Cart</button>
          </div>
        </div>
      </div>
    </section>
  );
}
